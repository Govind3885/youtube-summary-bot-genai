import streamlit as st
from pytube import YouTube
from transformers import pipeline

st.title("YouTube Video Summary Bot")
video_url = st.text_input("Enter YouTube video URL:")

if video_url:
    yt = YouTube(video_url)
    caption = yt.captions.get_by_language_code("en")
    if caption:
        raw_text = caption.generate_srt_captions()
        summarizer = pipeline("summarization")
        summary = summarizer(raw_text[:1000])[0]['summary_text']
        st.subheader("Summary:")
        st.write(summary)
    else:
        st.error("No English captions found.")