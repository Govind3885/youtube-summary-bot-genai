# YouTube Video Summary Bot using GenAI

This Streamlit app allows users to input a YouTube video link and receive an AI-generated summary based on the captions.

## How it works
- Extracts captions from the video using PyTube
- Uses HuggingFace's Transformers summarization pipeline (BART/T5)
- Displays a concise summary

## Requirements
- streamlit
- pytube
- transformers
- torch

## Run the app
```bash
streamlit run app.py
```